const Profile = require("../profile");
const errors = require("../structs/errors");
const { ApiException } = errors;
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");

Array.prototype.insert = function ( index, item ) {
    this.splice( index, 0, item );
};

module.exports = (app) => {
	app.post('/fortnite/api/game/v2/profile/:accountId/client/:command', function (req, res) {
		res.set("Content-Type", "application/json");
		var accountId = req.params.accountId;

		const getOrCreateProfile = profileId => {
			var profileData = Profile.readProfile(accountId, profileId);

			if (!profileData) {
				profileData = Profile.readProfileTemplate(profileId);

				if (!profileData) {
					throw new ApiException(errors.com.epicgames.modules.profiles.operation_forbidden).with(profileId);
				}

				profileData.created = profileData.updated = new Date().toISOString();
				profileData['_id'] = accountId;
				profileData.accountId = accountId;

				//creating profile if it doesn't exist
				try {
					fs.mkdirSync(`./config/${accountId}/profiles`, { recursive: true });
					Profile.saveProfile(accountId, profileId, profileData);
				} catch (e) {
					console.log("Failed creating profile");
					throw e;
				}
			}

			return {
				profileData,
				response: {
					"profileRevision": profileData.rvn || 1,
					"profileId": profileId,
					"profileChangesBaseRevision": profileData.rvn || 1,
					"profileChanges": [],
					"serverTime": new Date().toISOString(),
					"profileCommandRevision": profileData.commandRevision || 1,
					"responseVersion": 1
				}
			};
		};

		var command = req.params.command;
		var profileId = req.query.profileId || "common_core";
		const { profileData, response } = getOrCreateProfile(profileId);
		const { profileChanges } = response;
		const checkValidProfileID = (...validProfileIds) => checkValidProfileID0(command, profileId, ...validProfileIds);

		//profile commands
		switch (command) {
			case "QueryProfile":
			case "ClientQuestLogin":
				break;

			case "MarkItemSeen":
				checkValidProfileID("common_core", "campaign", "athena");
				req.body.itemIds.forEach(itemId => Profile.changeItemAttribute(profileData, itemId, "item_seen", true, profileChanges));
				break;
				
			case "RefreshExpeditions":
				checkValidProfileID("campaign");
				break;

			case "SetCosmeticLockerBanner": {
				checkValidProfileID("campaign", "athena");
				const item = profileData.items[req.body.lockerItem];

				if (!item) {
					throw new ApiException(errors.com.epicgames.fortnite.item_not_found).withMessage("Locker item {0} not found", req.body.lockerItem);
				}

				if (typeof req.body.bannerIconTemplateName === "string" && item.attributes.banner_icon_template != req.body.bannerIconTemplateName) {
					Profile.changeItemAttribute(profileData, req.body.lockerItem, "banner_icon_template", req.body.bannerIconTemplateName, profileChanges);
				}

				if (typeof req.body.bannerColorTemplateName === "string" && item.attributes.banner_color_template != req.body.bannerColorTemplateName) {
					Profile.changeItemAttribute(profileData, req.body.lockerItem, "banner_color_template", req.body.bannerColorTemplateName, profileChanges);
				}

				break;
			}

			case "EquipBattleRoyaleCustomization": {
				checkValidProfileID("campaign", "athena");
				
				var statName;

				switch (req.body.slotName) {
					case "Character":
						statName = "favorite_character"
						break;
					case "Backpack":
						statName = "favorite_backpack"
						break;
					case "Pickaxe":
						statName = "favorite_pickaxe"
						break;
					case "Glider":
						statName = "favorite_glider"
						break;
					case "SkyDiveContrail":
						statName = "favorite_skydivecontrail"
						break;
					case "MusicPack":
						statName = "favorite_musicpack"
						break;
					case "LoadingScreen":
						statName = "favorite_loadingscreen"
						break;
					case "Dance":
					case "ItemWrap":
						var bIsDance = req.body.slotName == "Dance";
						statName = bIsDance ? "favorite_dance" : "favorite_itemwraps";
						var arr = profileData.stats.attributes[statName] || [];
						if (req.body.indexWithinSlot == -1) {
							// handle wrap "Apply To All"
							arr = [];

							for (var i = 0; i < (bIsDance ? 6 : 7); ++i) {
								arr[i] = req.body.itemToSlot;
							}
						} else {
							arr[req.body.indexWithinSlot || 0] = req.body.itemToSlot;
						}

						for (var i = 0; i < arr.length; ++i) {
							if (arr[i] == null) {
								arr[i] = "";
							}
						}
						break;
				}
				
				if (req.body.variantUpdates.length > 0) {
					req.body.variantUpdates.forEach(x => delete x.owned)
					
					
					Profile.changeItemAttribute(profileData, req.body.itemToSlot, "variants", req.body.variantUpdates, profileChanges);
				}
				
				Profile.modifyStat(profileData, statName, req.body.itemToSlot, profileChanges);
			}

			case "SetItemFavoriteStatus":
				checkValidProfileID("campaign", "athena");

				if (typeof req.body.bFavorite === "boolean" && profileData.items[req.body.targetItemId].attributes.favorite != req.body.bFavorite) {
					Profile.changeItemAttribute(profileData, req.body.targetItemId, "favorite", req.body.bFavorite, profileChanges);
				}

				break;

			case "SetItemFavoriteStatusBatch":
				checkValidProfileID("campaign", "athena");
				req.body.itemIds.forEach((itemId, index) => {
					if (typeof itemId === "string" && typeof req.body.itemFavStatus[index] === "boolean") {
						Profile.changeItemAttribute(profileData, itemId, "favorite", req.body.itemFavStatus[index]), profileChanges;
					}
				});
				break;

			case "SetMtxPlatform":
				checkValidProfileID("common_core");

                response.profileChanges[0] = {
                    changeType: "statModified",
                    name: "current_mtx_platform",
                    value: req.body.newPlatform || "EpicPC"
                }

				break;

			default:
				throw new ApiException(errors.com.epicgames.fortnite.operation_not_found).with(req.params.command);
		}

		if (profileChanges.length > 0) {
			Profile.bumpRvn(profileData);
			response.profileRevision = profileData.rvn || 1;
			response.profileCommandRevision = profileData.commandRevision || 1;
			Profile.saveProfile(accountId, profileId, profileData);
		}

		var rvn = req.query.rvn || -1;

		if (rvn != response.profileChangesBaseRevision) {
			response.profileChanges = [{
				"changeType": "fullProfileUpdate",
				"profile": profileData
			}];
		}

		res.json(response);
	});
}

function checkValidProfileID0(command, sentProfileId, ...validProfileIds) {
	if (command && sentProfileId) {
		if (validProfileIds.indexOf(sentProfileId) == -1) {
			throw new ApiException(errors.com.epicgames.modules.profiles.invalid_command).with(command, `player:profile_${sentProfileId}`, sentProfileId);
		} else {
			return true;
		}
	}

	return true;
}
