const axios = require('axios');

module.exports = (app) => {
    app.get('/fortnite/api/calendar/v1/timeline', function (req, res) {
		res.json({
			channels: {
				"standalone-store": {
					states: [{
						validFrom: "2020-05-21T18:36:38.383Z",
						activeEvents: [],
						state: {
							activePurchaseLimitingEventIds: [],
							storefront: {},
							rmtPromotionConfig: [],							
							storeEnd: "0001-00-01T12:00:00.000Z"
						}
					}],
					cacheExpire: "9999-12-31T23:59:59.999Z"
				},
				"client-events": {
					states: [{
						validFrom: "2020-05-21T18:36:38.383Z",
						activeEvents: [
							{
								eventType: 'EventFlag.LobbySeason4',
								activeUntil: "9999-12-31T23:59:59.999Z",
								activeSince: "2019-12-31T23:59:59.999Z"
							}
						],
						state: {
							activeStorefronts: [],
							eventNamedWeights: {},
							activeEvents: [],
							seasonNumber: 4,
							seasonTemplateId: 'AthenaSeason:athenaseason4',
							matchXpBonusPoints: 100,
							eventPunchCardTemplateId: "",
							seasonBegin: "9999-12-31T23:59:59.999Z",
							seasonEnd: "9999-12-31T23:59:59.999Z",
							seasonDisplayedEnd: "9999-12-31T23:59:59.999Z",
							weeklyStoreEnd: "9999-12-31T23:59:59.999Z",
							stwEventStoreEnd: "9999-12-31T23:59:59.999Z",
							stwWeeklyStoreEnd: "9999-12-31T23:59:59.999Z",
							dailyStoreEnd: "9999-12-31T23:59:59.999Z"
						}
					}],
					cacheExpire: "9999-12-31T23:59:59.999Z"
				}
			},
			cacheIntervalMins: 15,
			currentTime: new Date()
		})
    })
}